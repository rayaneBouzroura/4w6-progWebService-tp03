import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-publicGalleries',
  templateUrl: './publicGalleries.component.html',
  styleUrls: ['./publicGalleries.component.css']
})
export class PublicGalleriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
