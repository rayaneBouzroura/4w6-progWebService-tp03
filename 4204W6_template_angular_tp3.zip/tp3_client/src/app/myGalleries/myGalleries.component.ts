import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myGalleries',
  templateUrl: './myGalleries.component.html',
  styleUrls: ['./myGalleries.component.css']
})
export class MyGalleriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
